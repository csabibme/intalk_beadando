<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['elsoSzam']) && isset($_POST['masodikSzam']) && isset($_POST['muvelet'])) {
        $elsoSzam = $_POST['elsoSzam'];
        $masodikSzam = $_POST['masodikSzam'];
        $muvelet = $_POST['muvelet'];

        switch ($muvelet) {
            case '+':
                $eredmeny = $elsoSzam + $masodikSzam;
                break;
            case '-':
                $eredmeny = $elsoSzam - $masodikSzam;
                break;
            case '*':
                $eredmeny = $elsoSzam * $masodikSzam;
                break;
            case '/':
                if ($masodikSzam != 0)
                    $eredmeny = $elsoSzam / $masodikSzam;
                else
                    die(json_encode(array('error' => 'Nullával történő osztás nem megengedett!')));
                break;
            default:
                die(json_encode(array('error' => 'Hibás Művelet')));
        }

        // Return the result as JSON
        echo json_encode(array('result' => $eredmeny));
    } else {
        // Return an error response if required parameters are missing
        echo json_encode(array('error' => 'Hiányzó bemeneti paraméterek!'));
    }
} else {
    // Return an error response for unsupported request methods
    echo json_encode(array('error' => 'Nem megengedett hívás!'));
}
?>
