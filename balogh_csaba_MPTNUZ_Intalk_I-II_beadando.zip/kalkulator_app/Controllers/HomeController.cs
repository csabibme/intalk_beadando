using Microsoft.AspNetCore.Mvc;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Szamol(int elsoSzam, int masodikSzam, string muvelet)
    {
        try
        {
            using (var httpClient = new HttpClient())
            {
                httpClient.BaseAddress = new Uri("http://devtronics.hopto.org");

                var postData = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("elsoSzam", elsoSzam.ToString()),
                    new KeyValuePair<string, string>("masodikSzam", masodikSzam.ToString()),
                    new KeyValuePair<string, string>("muvelet", muvelet)
                });

                var response = await httpClient.PostAsync("szamol.php", postData);
                response.EnsureSuccessStatusCode();

                // Eredm�ny kiovasa�sa JSON v�laszb�l most parse-ol�s n�lk�l csin�ltam.
                var responseContent = await response.Content.ReadAsStringAsync();
                var resultIndex = responseContent.IndexOf(":") + 1;
                var result = responseContent.Substring(resultIndex, responseContent.Length - resultIndex - 1).Trim();

                ViewBag.Result = result;
            }
        }
        catch (Exception ex)
        {
            ViewBag.Result = "Hiba t�rt�nt: " + ex.Message;
        }
        return View("Index");
    }
}
